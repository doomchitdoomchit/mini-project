# Flask_practice

https://www.youtube.com/watch?v=Qr4QMBUPxWo&t=17621s
